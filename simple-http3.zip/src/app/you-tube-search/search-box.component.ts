import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  ElementRef
} from '@angular/core';

// By importing just the rxjs operators we need, We're theoretically able
// to reduce our build size vs. importing all of them.
import { Observable, fromEvent  } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

import { YouTubeSearchService } from './you-tube-search.service';
import { SeachResult } from './search-result.model';

@Component({
  selector: 'app-search-box',
  template: `
    <div class="ui  icon input">
      <input type="text" class="form-control" placeholder="Search" autofocus>
      <i class="inverted circular search link icon"></i>
    </div>
  `
})
export class SearchBoxComponent implements OnInit {
  @Output() loading: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() results: EventEmitter<SeachResult[]> = new EventEmitter<SeachResult[]>();

  constructor(private youtube: YouTubeSearchService,
              private el: ElementRef) {
  }

  ngOnInit(): void {

    fromEvent(this.el.nativeElement, 'keyup')
    .pipe(debounceTime(500))
    .subscribe((evt: KeyboardEvent ) => {
      // Log coords of mouse movements
      this.loading.emit(true);
      console.log(evt.key);
      this.youtube.search(evt.key).subscribe(resp => {
          for ( const mo of resp['items']) {
            console.log(mo);
          }
          this.loading.emit(false);
      });
    });

    // convert the `keyup` event into an observable stream
    // Observable.fromEvent(this.el.nativeElement, 'keyup')
    //   .map((e: any) => e.target.value) // extract the value of the input
    //   .filter((text: string) => text.length > 1) // filter out if empty
    //   .debounceTime(250)                         // only once every 250ms
    //   .do(() => this.loading.emit(true))         // enable loading
    //   // search, discarding old events if new input comes in
    //   .map((query: string) => this.youtube.search(query))
    //   .switch()
    //   // act on the return of the search
    //   .subscribe(
    //     (results: SeachResult[]) => { // on sucesss
    //       this.loading.emit(false);
    //       this.results.emit(results);
    //     },
    //     (err: any) => { // on error
    //       console.log(err);
    //       this.loading.emit(false);
    //     },
    //     () => { // on completion
    //       this.loading.emit(false);
    //     }
    //   );
  }
}
